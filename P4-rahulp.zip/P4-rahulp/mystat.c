#include <unistd.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
 #include <dirent.h>
#include<time.h>
#include<pwd.h>
#include<grp.h>
void printinfo(char *infofile);
int main(int argc, char **argv)
{
    struct stat info;

      if(argc==1)
  {
      printf("error !!! enter the specific folder/file name ");
  }

    if(argc != 2)  
    //printf("error !!! enter the specific folder/file name ");  
        return 0;

  
    
  printinfo(argv[1]);

return 0;

}

void printinfo(char *infofile)

{

struct stat info;
    //printf("Information for %s\n",argv[1]);
    stat(infofile,&info);    
        
    printf("File name :\t%s\t",infofile);
    printf("Size: \t%d bytes\n",info.st_size);
    printf("No of Links: \t%d\n",info.st_nlink);
    printf("Inode: \t%d\n",info.st_ino);
	printf("Blocks: \t%d\n",info.st_blocks);
    printf(" Permissions: \t");
   if(S_ISDIR(info.st_mode))
        printf("d");
   else
         printf("_");
  
    if((info.st_mode & S_IRUSR))
       printf("r");
     else
         printf("_");

 if((info.st_mode & S_IWUSR))
       printf("w");
     else
         printf("_");

 if((info.st_mode & S_IXUSR))
       printf("x");
     else
         printf("_");

 if((info.st_mode & S_IRGRP))
       printf("r");
     else
         printf("_");

 if((info.st_mode & S_IWGRP))
       printf("w");
     else
         printf("_");

 if((info.st_mode & S_IXGRP))
       printf("x");
     else
         printf("_");


if((info.st_mode & S_IROTH))
       printf("r");
     else
         printf("_");

 if((info.st_mode & S_IWOTH))
       printf("w");
     else
         printf("_");

 if((info.st_mode & S_IXOTH))
       printf("x");
     else
         printf("_");

    
}
