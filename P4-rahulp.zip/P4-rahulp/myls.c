#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include<time.h>
#include<pwd.h>
#include<grp.h>
int main(int argc, char* argv[])
{
    DIR *directory;
    struct dirent *file;
    struct stat info;

    char date[20];
	struct passwd *info2;
      struct group *info3;
    char buf[512];
    directory = opendir(argv[2]);
      char l;
char * inputfile = argv[2];

printf("groupname\townername   \tSize\tlinks\t\tblocks\t\tpermissions\t Date and Time\t\t\t\tFilename \n ");

  stat(argv[2], &info);
//checking whether the input is a file or folder
if(!(S_ISDIR(info.st_mode)))
{

		
	info2= getpwuid(info.st_uid);
	info3=getgrgid(info.st_gid);

	
        printf(" %s\t",info2->pw_name);
        printf(" \t%s\t",info3->gr_name);
        printf(" \t%zu \t",info.st_size);
        printf(" \t%d\t", info.st_nlink);
        printf(" \t%d\t",info.st_blocks);
     //printf("File Permissions: \t");

  if(S_ISDIR(info.st_mode))
        printf("d");
   else
         printf("_");
  
    if((info.st_mode & S_IRUSR))
       printf("r");
     else
         printf("_");

 if((info.st_mode & S_IWUSR))
       printf("w");
     else
         printf("_");

 if((info.st_mode & S_IXUSR))
       printf("x");
     else
         printf("_");

 if((info.st_mode & S_IRGRP))
       printf("r");
     else
         printf("_");

 if((info.st_mode & S_IWGRP))
       printf("w");
     else
         printf("_");

 if((info.st_mode & S_IXGRP))
       printf("x");
     else
         printf("_");


if((info.st_mode & S_IROTH))
       printf("r");
     else
         printf("_");

 if((info.st_mode & S_IWOTH))
       printf("w");
     else
         printf("_");

 if((info.st_mode & S_IXOTH))
       printf("x");
     else
         printf("_");   

    printf("\t%s\t ",ctime(&info.st_mtime));
	printf("\t %s\t", inputfile);
 
printf("\n");
return 0;
}

//if the input is a folder
// check whether -l is given or not

    if(strcmp(argv[1],"-l")==0)

{
    while((file = readdir(directory)) != 0)
    {
   
   
        sprintf(buf, "%s/%s", argv[2], file->d_name);
        stat(buf, &info);
	
      if(stat(argv[2],&info) < 0)    
        return 1;

	info2= getpwuid(info.st_uid);
	info3=getgrgid(info.st_gid);

	
        printf(" %s\t",info2->pw_name);
        printf(" \t%s\t",info3->gr_name);
        printf(" \t%zu \t",info.st_size);
        printf(" \t%d\t", info.st_nlink);
        printf(" \t%d\t",info.st_blocks);
    

  if(S_ISDIR(info.st_mode))
        printf("d");
   else
         printf("_");
  
    if((info.st_mode & S_IRUSR))
       printf("r");
     else
         printf("_");

 if((info.st_mode & S_IWUSR))
       printf("w");
     else
         printf("_");

 if((info.st_mode & S_IXUSR))
       printf("x");
     else
         printf("_");

 if((info.st_mode & S_IRGRP))
       printf("r");
     else
         printf("_");

 if((info.st_mode & S_IWGRP))
       printf("w");
     else
         printf("_");

 if((info.st_mode & S_IXGRP))
       printf("x");
     else
         printf("_");


if((info.st_mode & S_IROTH))
       printf("r");
     else
         printf("_");

 if((info.st_mode & S_IWOTH))
       printf("w");
     else
         printf("_");

 if((info.st_mode & S_IXOTH))
       printf("x");
     else
         printf("_");
   

    printf("\t%s\t\t%s\t ",ctime(&info.st_mtime), file->d_name);
 
printf("\n");           
         
    }


}


    closedir(directory);
}
