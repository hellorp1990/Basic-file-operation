
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>

void listtree(const char *filename, int l)
{
    DIR *directory;
    struct dirent *file;
	int c=0;
      int a,i=0;
    if (!(directory = opendir(filename)) || !(file = readdir(directory)))
        return;
    
     directory= opendir(filename);
       c++;
     if(directory != NULL)
   {
    do {
        if (file->d_type == DT_DIR) {
            char path[2048];
            int len = snprintf(path, sizeof(path)-1, "%s/%s", filename, file->d_name);
            path[len] = 0;
            if (strcmp(file->d_name, "..") == 0 || strcmp(file->d_name, ".") == 0  )
                continue;
              while(i<c)
               {
                            printf("|");
                            i++;
               }
            printf("%*s--[[%s]]\n", l, "", file->d_name);
          // printf("|");
            listtree(path, l + 1);
        }
        else
            printf("%*s-- %s\n", l, "", file->d_name);
	//printf("|");
    } while (file = readdir(directory));
}
c--;
    closedir(directory);
}

int main(int argc, char* argv[])
{
              if(argc==1)
  {
      printf("error !!! enter the specific folder/file name ");
  }
      

    listtree(argv[1], 0);
    return 0;
}
