#include <stdio.h>
#include <stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>

int main(int argc, char* argv[])
{
    FILE *in;
    int count = 0;
    long int position;
    char s[100];
	char * inputfile = argv[1];
        
    int a,d; 
    int c;
 //opening the file and error checking
 if((in = fopen(inputfile,"r")) == NULL )
                printf(" file %s open error\n",inputfile);
       
		
	//printf("Enter how many lines to be printed");
	//scanf("%d",&c);
     //scanfc = argv[2];

    sscanf(argv[2],"%d",&c);
     //printf("the %s lines are following",c);
//calculating the file length
    fseek(in, 0, SEEK_END);
    //lseek(in, 0, SEEK_END);
    position = ftell(in);
 

     do{
              /* search from start */
        fseek(in, --position, SEEK_SET); 

        if (fgetc(in) == '\n') {

	// counting the number of lines that is intended
		d=count++;
            
		if (d == c) 
		break;
        }
    }while (position);

    a= sizeof(s);

     do{ 
                
      printf("%s",s);
    }while (fgets(s, a, in) != 0);


    fclose(in);
    
    return 0;
}
